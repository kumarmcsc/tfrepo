<?php

/**
 * No Replies Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<div class="bbp-template-notice">
	<p><?php esc_html_e( 'Oh bother! No replies were found here!', 'hub' ); ?></p>
</div>
