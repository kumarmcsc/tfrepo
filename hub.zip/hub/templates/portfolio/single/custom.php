<div class="pf-single-contents clearfix">
	<?php the_content() ?>
</div>