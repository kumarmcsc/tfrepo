<div class="lqd-preloader-wrap lqd-preloader-dissolve"
data-preloader-options='{ "animationType": "scale", "animationTargets": ".lqd-preloader-dissolve-el", "stagger": 12, "dir": "y", "duration": 600 }'>
	<div class="lqd-preloader-inner d-flex flex-column">

		<?php for ( $i = 0; $i <= 26; $i++ ) : ?>
			<div class="lqd-preloader-dissolve-el w-100 flex-grow-1"></div>
		<?php endfor; ?>

	</div>
</div>