<div class="lqd-preloader-wrap lqd-preloader-frame" data-preloader-options='{ "animationType": "slide", "animationTargets": ".lqd-preloader-frame-el" }'>
	<div class="lqd-preloader-inner">

		<span class="lqd-preloader-frame-el lqd-preloader-frame-top" data-preloader-qxis="y" data-animations='{ "keyframes": [{"translateY": "0%"}, {"translateY": "-100%", "ease": "power1.out"}] }'></span>
		<span class="lqd-preloader-frame-el lqd-preloader-frame-right" data-preloader-qxis="x" data-animations='{ "keyframes": [{"translateX": "0%"}, {"translateX": "100%", "ease": "power1.out"}] }'></span>
		<span class="lqd-preloader-frame-el lqd-preloader-frame-bottom" data-preloader-qxis="y" data-animations='{ "keyframes": [{"translateY": "0%"}, {"translateY": "100%", "ease": "power1.out"}] }'></span>
		<span class="lqd-preloader-frame-el lqd-preloader-frame-left" data-preloader-qxis="x" data-animations='{ "keyframes": [{"translateX": "0%"}, {"translateX": "-100%", "ease": "power1.out"}] }'></span>

	</div>
</div>