<div class="lqd-preloader-wrap lqd-preloader-sliding" data-preloader-options='{ "animationType": "slide", "animationTargets": ".lqd-preloader-sliding-el" }'>
	<div class="lqd-preloader-inner">
		<div class="lqd-preloader-sliding-el lqd-overlay"></div>
	</div>
</div>